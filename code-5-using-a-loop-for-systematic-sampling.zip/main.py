import math
import random

def calculate_sample_size(population_size, confidence_level, margin_of_error):
    # Z-scores for confidence levels (95 or 99)
    z_scores = {
        95: 1.96,
        99: 2.576
    }
    
    # Assume 0.5 for P if it's unknown
    P = 0.5
    E = margin_of_error
    
    # Get the Z value based on the confidence level
    Z = z_scores.get(confidence_level)
    if Z is None:
        raise ValueError("Confidence level must be 95 or 99.")
    
    # Formula to find the sample size
    sample_size = (Z**2 * P * (1 - P)) / E**2
    
    # Round up to the nearest whole number
    sample_size = math.ceil(sample_size)
    return min(sample_size, population_size)

def systematic_sampling(population, sample_size):
    n = len(population)
    k = n // sample_size  # Interval between samples
    sampled_elements = []
    
    # Randomly pick where to start
    start = random.randint(0, k - 1)
    
    # Loop to pick samples at regular intervals
    for i in range(sample_size):
        index = start + i * k
        # Make sure index is in range
        if index < n:
            sampled_elements.append(population[index])
    
    return sampled_elements

def main():
    # User input
    population_size = int(input("Enter the population size: "))
    confidence_level = int(input("Enter the confidence level (e.g., 95 or 99): "))
    margin_of_error = float(input("Enter the desired margin of error (e.g., 0.05 for 5%): "))
    
    # Calculate sample size needed
    required_sample_size = calculate_sample_size(population_size, confidence_level, margin_of_error)
    
    print(f"The required sample size for systematic sampling is approximately {required_sample_size}.")

    # User input for how many samples they want
    desired_sample_size = int(input("Enter the sample size you want to draw: "))

    # Check if requested size is too large
    if desired_sample_size > required_sample_size:
        print("Sorry, that's too many samples.")
        print(f"Maximum possible is {required_sample_size}. Please choose a smaller number.")
        desired_sample_size = int(input("Enter the sample size you want to draw: "))
    
    # Make a list for the population (1 to population_size)
    population = list(range(1, population_size + 1))
    
    # Do the systematic sampling
    sampled_elements = systematic_sampling(population, desired_sample_size)
    
    print("The sampled elements are:")
    print(sampled_elements)

if __name__ == "__main__":
    main()
